"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.
"""

from __future__ import annotations

import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


# Text model preference, best first. Matched as substrings so a renamed or
# newer alias in the event roster (e.g. "gpt-5.7-terra") still ranks sensibly.
# Practice benchmark (6-person seating puzzle, 4 trials each, all correct):
#   gpt-5.6-terra     ~10s   ~650 tokens
#   gemini-3.8-flash  ~11s  ~1400 tokens
#   gemini-3.6-flash  ~11s  ~2400 tokens
# gpt-5.4 was fast but wrong on the hard puzzle; qwen3.7-max ignored the
# ANSWER format; nemotron-3.5-lightning and nemotron-3-ultra ran out of tokens.
_TEXT_PREFERENCE = (
    "terra",
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini",
    "gpt-5.6",
    "gpt-5",
    "nemotron-3-super",
    "qwen3.7-plus",
    "qwen3.6",
    "qwen3.7-flash",
)
# Models that burned their whole token budget or broke the output format on Practice.
_TEXT_LAST = ("lightning", "nemotron-3-ultra", "qwen3.7-max")

# Practice image probe (same edit/generate tasks):
#   edit:     flash-image ~18s, cleanest preservation; pro-image ~33s; flash-lite ~7s but
#             its cap covered the subject's eyes.
#   generate: with the no-text guidance below, only pro-image drew zero text (~35s);
#             flash-image still drew readable signs.
_IMAGE_EDIT_PREFERENCE = ("flash-image", "pro-image", "image")
_IMAGE_GENERATE_PREFERENCE = ("pro-image", "flash-image", "image")
_IMAGE_LAST = ("lite",)

# Image models ignore "no text" and draw readable signs anyway (judge constraints: 50),
# so state the constraint as what to draw instead.
_NO_TEXT = re.compile(r"\bno (?:visible )?(?:text|words|letters|lettering|typography)\b|avoid[^.]*\btext\b", re.I)
_NO_TEXT_GUIDANCE = (
    "Hard constraint: the image must contain zero text. Every sign, screen, billboard, label and "
    "surface is blank or shows only abstract glowing shapes and color. No letters, numbers, "
    "characters from any script, logos, symbols or watermarks anywhere."
)

_ANSWER_PREFIX = re.compile(r"^\s*(?:final\s+)?answer\s*[:\-]\s*", re.IGNORECASE)


def _rank_by_preference(
    models: list[str],
    preference: tuple[str, ...],
    last: tuple[str, ...] = (),
) -> list[str]:
    """Stable sort: preferred substrings first (in order), `last` matches at the end."""

    def key(item: tuple[int, str]) -> tuple[int, int]:
        index, name = item
        lowered = name.lower()
        if any(token in lowered for token in last):
            return (len(preference) + 1, index)
        for rank, token in enumerate(preference):
            if token in lowered:
                return (rank, index)
        return (len(preference), index)

    return [name for _, name in sorted(enumerate(models), key=key)]


class MyStrategy(BaseStrategy):
    """Format-strict solver with benchmark-driven model ranking."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "team-saitron"
    agent_name = "Team Saitron"

    # Text challenge strategy
    text_system_prompt = (
        "You solve logic, reasoning, retrieval, and structured-output puzzles for a scored competition. "
        "An automated judge compares your answer to the expected result AND the required format, "
        "so a correct answer in the wrong format scores zero.\n"
        "Method: read every clue, work out the answer carefully, then check it against every clue "
        "and every rule before you reply.\n"
        "Reply format: exactly one line, `ANSWER: <final answer>`, where <final answer> follows the "
        "challenge's Rules character for character (separators, casing, ordering, units, JSON shape). "
        "No reasoning, no markdown, no quotes, no code fences, no trailing period unless the rules ask "
        "for one. Never answer 'unknown'; give your best answer."
    )
    text_strategy_notes = "Verify against every clue before answering; output only the ANSWER line."
    text_temperature = 0.0
    # A cap, not a spend: token efficiency counts tokens used. Fallback reasoning
    # models need the headroom (nemotron ran out at 4096 on an easy puzzle).
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Edit only what the instruction asks for and keep everything else in the source image intact. "
        "For generation, satisfy every explicit constraint (subjects, counts, colors, style, 'no text')."
    )

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available_models)
            if image_models:
                preference = _IMAGE_EDIT_PREFERENCE if ctx.image_url else _IMAGE_GENERATE_PREFERENCE
                return _rank_by_preference(image_models, preference, _IMAGE_LAST)
        text_models = [m for m in available_models if "image" not in m.lower()] or list(available_models)
        return _rank_by_preference(text_models, _TEXT_PREFERENCE, _TEXT_LAST)

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = "\n".join(f"{i}. {clue.strip()}" for i, clue in enumerate(ctx.clues, 1) if clue.strip())
        rules = ctx.rules.strip() or "No additional rules provided."
        difficulty = "" if ctx.difficulty in ("", "unknown") else f" (difficulty: {ctx.difficulty})"
        return (
            f"Challenge type: {ctx.challenge_type.strip() or 'text'}{difficulty}\n"
            f"Task: {ctx.description.strip() or ctx.challenge_text.strip() or 'No description provided.'}\n\n"
            f"Clues:\n{clues or '(none)'}\n\n"
            f"REQUIRED ANSWER FORMAT (follow exactly): {rules}\n\n"
            "Before replying, confirm your answer satisfies every numbered clue and the format above.\n"
            "Reply with exactly one line: ANSWER: <final answer>"
        )

    def on_time_warning(self, remaining_s: float, current_answer: str, ctx: ChallengeContext) -> str | None:
        """Last pass before submit: strip wrappers the judge would count against format."""
        _ = remaining_s
        answer = (current_answer or "").strip()
        if not answer:
            return None
        answer = _ANSWER_PREFIX.sub("", answer).strip()
        if answer.startswith("```") and answer.endswith("```"):
            answer = answer.strip("`").strip()
            answer = re.sub(r"^(?:json|text)\s*\n", "", answer, flags=re.IGNORECASE).strip()
        if len(answer) >= 2 and answer[0] == answer[-1] and answer[0] in "\"'`":
            answer = answer[1:-1].strip()
        # Drop a trailing period the rules didn't ask for (e.g. "Ava, Ben, Maya, Leo.").
        if answer.endswith(".") and "period" not in ctx.rules.lower() and not re.search(r"\d\.$", answer):
            answer = answer[:-1].rstrip()
        return answer or current_answer

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        prompt = f"{super().build_image_prompt(ctx)}\n\nGuidance: {self.image_strategy_notes}"
        if ctx.image_url:
            prompt += (
                "\nChange only the requested element. Keep the subject's face, pose, proportions, "
                "materials, lighting, framing and background exactly as in the source image, and do "
                "not cover or reshape existing features. Any added item is plain: no logos, letters "
                "or emblems unless the instruction asks for them."
            )
        if _NO_TEXT.search(f"{ctx.rules} {ctx.challenge_text}"):
            prompt += f"\n{_NO_TEXT_GUIDANCE}"
        return prompt
